import { Route, Routes } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Home } from './pages/Home';
import { Explore } from './pages/Explore';
import { ChallengeDetail } from './pages/ChallengeDetail';
import { SubmitIdea } from './pages/SubmitIdea';
import { Workspace } from './pages/Workspace';
import { Learn } from './pages/Learn';
import { PathDetail } from './pages/PathDetail';
import { Knowledge } from './pages/Knowledge';
import { LibraryCategory } from './pages/LibraryCategory';
import { Leaderboard } from './pages/Leaderboard';
import { Help } from './pages/Help';
import { NotFound } from './pages/NotFound';

export function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="explore" element={<Explore />} />
        <Route path="explore/:id" element={<ChallengeDetail />} />
        <Route path="ideas/new" element={<SubmitIdea />} />
        <Route path="workspace" element={<Workspace />} />
        <Route path="learn" element={<Learn />} />
        <Route path="learn/paths/:id" element={<PathDetail />} />
        <Route path="knowledge" element={<Knowledge />} />
        <Route path="knowledge/library/:slug" element={<LibraryCategory />} />
        <Route path="leaderboard" element={<Leaderboard />} />
        <Route path="help" element={<Help />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}
