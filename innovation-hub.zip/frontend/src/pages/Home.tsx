import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, BookOpen, Lightbulb, Target } from 'lucide-react';
import { useApi } from '../api/client';
import type { HomeData, LeaderboardData } from '../api/types';
import { useApp } from '../state/AppContext';
import { PageHeader } from '../components/PageHeader';
import { PortfolioHorizons } from '../components/PortfolioHorizons';
import { Placeholder } from '../components/Placeholder';
import { Avatar, CtaLink, ErrorMsg, Loading, ProgressBar, Tabs } from '../components/Bits';

function greeting(): string {
  const h = new Date().getHours();
  return h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
}

export function Home() {
  const { user } = useApp();
  const home = useApi<HomeData>('/home');
  const [tab, setTab] = useState<'learning' | 'ideas'>('learning');
  const lb = useApi<LeaderboardData>(`/leaderboard?tab=${tab}&limit=3`);
  const first = user.name.split(' ')[0];

  return (
    <>
      <PageHeader title="Innovation Hub" />
      <p className="greeting">{greeting()}, {first}. What would you like to improve today?</p>

      <Link to="/ideas/new" className="hero">
        <div className="hero__copy">
          <h2>Innovation starts with all of us.</h2>
          <p>Improve what we do today. Explore new opportunities. Create what comes next.</p>
          <p>Discover business challenges, develop your capabilities and turn promising ideas into measurable value.</p>
          <span className="btn btn--primary">Submit an idea <ArrowRight size={14} /></span>
        </div>
        <Placeholder dark label="Hero image" className="hero__img" />
        <div className="hero__next"><span>YOUR NEXT STEP</span><strong>Submit an idea</strong></div>
      </Link>

      <PortfolioHorizons />

      <h2 className="h2">Your personal innovation dashboard</h2>
      {home.error && <ErrorMsg text={home.error} />}
      {home.loading && !home.data && <Loading />}
      {home.data && (
        <div className="grid-4">
          <Link to="/workspace" className="card tile">
            <span className="tile__label">My ideas</span>
            <span className="tile__num">{home.data.tiles.ideas.count}</span>
            <ul className="tile__list">
              {home.data.tiles.ideas.items.map((i, k) => <li key={k}>{i.title} · {i.status}</li>)}
            </ul>
          </Link>
          <Link to="/workspace" className="card tile">
            <span className="tile__label">My active experiments</span>
            <span className="tile__num">{home.data.tiles.experiments.count}</span>
            <ul className="tile__list">
              {home.data.tiles.experiments.items.map((e, k) => <li key={k}>{e.title} · {e.status}</li>)}
              {home.data.tiles.experiments.next_review && <li>Next review: {home.data.tiles.experiments.next_review}</li>}
            </ul>
          </Link>
          <Link to="/learn" className="card tile">
            <span className="tile__label">My learning progress</span>
            <span className="tile__num">{home.data.tiles.learning.percent}%</span>
            <ul className="tile__list">
              <li>{home.data.tiles.learning.title}</li>
              <li>{home.data.tiles.learning.in_progress_text}</li>
            </ul>
            <div className="tile__bar"><ProgressBar percent={home.data.tiles.learning.percent} /></div>
          </Link>
          <div className="card tile">
            <span className="tile__label">My next actions</span>
            <span className="tile__num">{home.data.tiles.next_actions.count}</span>
            <ul className="tile__list">
              {home.data.tiles.next_actions.items.map((a, k) => <li key={k}>{a}</li>)}
            </ul>
          </div>
        </div>
      )}

      <section className="card leaders">
        <div className="leaders__head">
          <h2>Learning &amp; idea leaders</h2>
          <span className="small muted">This quarter • Sample rankings</span>
        </div>
        <Tabs tabs={[{ id: 'learning', label: 'Learning' }, { id: 'ideas', label: 'Ideas submitted' }]}
              value={tab} onChange={setTab} />
        {lb.error && <ErrorMsg text={lb.error} />}
        {lb.data && (
          <>
            <div className="leaders__cols small"><span>COLLEAGUE</span><span>{lb.data.column_label.toUpperCase()}</span></div>
            <ol className="leaders__list">
              {lb.data.entries.map((e) => (
                <li key={e.user_id} className="leaders__row">
                  <span className="leaders__rank">{e.rank}</span><Avatar initials={e.initials} />
                  <span className="leaders__name">{e.name}</span><strong>{e.value}</strong>
                </li>
              ))}
            </ol>
            <div className="leaders__me">
              <span className="leaders__me-init">{lb.data.me.initials}</span>
              <span>Your contribution • <strong>{lb.data.me.name}</strong></span>
              <strong className="leaders__me-sum">{lb.data.me.summary}</strong>
            </div>
            <div className="leaders__foot">
              <CtaLink to="/leaderboard" caps={false}>View full leaderboard</CtaLink>
              <span className="small muted">Learning and ideas are ranked separately.</span>
            </div>
            <p className="small muted">{lb.data.note}</p>
          </>
        )}
      </section>

      <h2 className="h2">Where you can contribute</h2>
      <div className="grid-3">
        <div className="card contribute">
          <h3><Target size={20} /> Explore a challenge</h3>
          <p>Help solve a real customer, process or growth problem.</p>
          <span className="small muted">{home.data?.challenge_count ?? 0} illustrative challenges</span>
          <CtaLink to="/explore">Explore challenges</CtaLink>
        </div>
        <div className="card contribute">
          <h3><Lightbulb size={20} /> Share an idea</h3>
          <p>Suggest an improvement or a new opportunity.</p>
          <span className="small muted">Develop your opportunity</span>
          <CtaLink to="/ideas/new">Submit idea</CtaLink>
        </div>
        <div className="card contribute">
          <h3><BookOpen size={20} /> Learn and connect</h3>
          <p>Build practical skills and find people to collaborate with.</p>
          <span className="small muted">Innovation Academy</span>
          <CtaLink to="/learn">View academy</CtaLink>
        </div>
      </div>

      {home.data?.featured_challenge && (
        <>
          <h2 className="h2">Featured opportunity</h2>
          <div className="card card--accent featured">
            <span className="tagline">
              {home.data.featured_challenge.horizon.toUpperCase()} • {home.data.featured_challenge.types.join(' / ').toUpperCase()} • ILLUSTRATIVE CHALLENGE
            </span>
            <h3>{home.data.featured_challenge.title}</h3>
            <p className="muted">{home.data.featured_challenge.how_might_we}</p>
            <CtaLink to={`/explore/${home.data.featured_challenge.id}`}>Explore this challenge</CtaLink>
          </div>
        </>
      )}
    </>
  );
}
