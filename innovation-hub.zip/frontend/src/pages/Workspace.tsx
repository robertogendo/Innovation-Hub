import { useEffect, useMemo, useRef } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { useApi } from '../api/client';
import type { IdeaDetail, RecordCard, RecordDetail } from '../api/types';
import { useApp } from '../state/AppContext';
import { PageHeader } from '../components/PageHeader';
import { StageGate } from '../components/StageGate';
import { ErrorMsg, Loading } from '../components/Bits';

const NOTE_ORDER = ['Strategic alignment', 'Customer value', 'Feasibility', 'Risk and compliance', 'Potential impact'];
const noteRank = (k: string) => (NOTE_ORDER.includes(k) ? NOTE_ORDER.indexOf(k) : NOTE_ORDER.length);

function RecordTile({ r, selected, onOpen }: { r: RecordCard; selected: boolean; onOpen: () => void }) {
  const meta = [r.owner, r.horizon, r.types.join(' / ')].filter(Boolean).join(' • ');
  return (
    <article className={`card record ${r.kind === 'idea' ? 'record--idea' : 'record--exp'} ${selected ? 'is-selected' : ''}`}>
      <span className="tagline tagline--plain">
        {r.kind.toUpperCase()} • {r.is_draft ? 'DRAFT' : r.stage.toUpperCase()}
      </span>
      <h3>{r.title}</h3>
      <span className="pill">{r.status}</span>
      <p className="muted small-lines">Owner: {meta}<br />{r.next_label}: {r.next_text}</p>
      {r.is_draft
        ? <Link to={`/ideas/new?draft=${r.id}`} className="cta record__open">Continue draft <ArrowRight size={14} /></Link>
        : <button className="cta record__open" onClick={onOpen}>Open record <ArrowRight size={14} /></button>}
    </article>
  );
}

export function Workspace() {
  const { user } = useApp();
  const [params, setParams] = useSearchParams();
  const ws = useApi<{ ideas: RecordCard[]; experiments: RecordCard[] }>('/workspace');
  const panel = useRef<HTMLDivElement>(null);

  const all = useMemo(() => [...(ws.data?.ideas ?? []), ...(ws.data?.experiments ?? [])], [ws.data]);
  const wanted = params.get('record');
  const selected = all.find((r) => r.key === wanted && !r.is_draft)
    ?? ws.data?.experiments[0] ?? all.find((r) => !r.is_draft) ?? null;

  const detail = useApi<RecordDetail | IdeaDetail>(selected ? `/${selected.kind === 'idea' ? 'ideas' : 'experiments'}/${selected.id}` : null);

  useEffect(() => {
    if (wanted && detail.data && panel.current) panel.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, [wanted, detail.data?.key]); // eslint-disable-line react-hooks/exhaustive-deps

  const d = selected && detail.data?.key === selected.key ? detail.data : null;
  const first = user.name.split(' ')[0];

  return (
    <>
      <PageHeader title="My innovation workspace"
                  subtitle="Track your ideas and experiments from first review to validated learning and implementation." />
      <h2 className="h2">My records</h2>
      {ws.error && <ErrorMsg text={ws.error} />}
      {ws.loading && !ws.data && <Loading />}
      {ws.data && all.length === 0 && (
        <div className="card empty"><strong>You have no records yet.</strong>
          <p className="muted">Submit an idea to start. <Link to="/ideas/new">Submit an idea</Link></p></div>
      )}
      <div className="grid-2">
        {all.map((r) => (
          <RecordTile key={r.key} r={r} selected={selected?.key === r.key}
                      onOpen={() => setParams({ record: r.key })} />
        ))}
      </div>

      <StageGate active={selected?.stage} />

      <div ref={panel} className="scroll-anchor" />
      {selected && <h2 className="h2">Selected initiative · {selected.title}</h2>}
      {selected && detail.error && <ErrorMsg text={detail.error} />}
      {selected && !d && !detail.error && <Loading />}
      {d && (
        <>
          <section className="card selected">
            <span className="tagline">{d.tag}</span>
            <div className="selected__cols">
              <div>
                <h3>Owner: {d.owner}</h3>
                <p className="muted small-lines">
                  Primary horizon: {d.horizon ?? 'Not set'}<br />
                  Innovation types: {d.types.length ? d.types.join(' / ') : 'Not set'}<br />
                  Current stage: {d.stage.toUpperCase()}<br />
                  Sponsor / decision owner: {d.sponsor ?? 'Not yet assigned'}
                </p>
              </div>
              <div>
                <h3>Evidence &amp; learning</h3>
                <p className="muted small-lines">{d.evidence_lines.map((l, i) => <span key={i}>{l}<br /></span>)}</p>
              </div>
            </div>
            <p className="selected__next">
              {d.next_label}: {d.next_text}
              {d.can_edit && <Link to={`/ideas/new?draft=${d.id}`} className="cta selected__edit">Edit and resubmit <ArrowRight size={14} /></Link>}
            </p>
            {d.resource_decision && <p className="muted">Resource decision: {d.resource_decision}</p>}
          </section>

          <section className="card card--grey before">
            <h3>Before the next decision</h3>
            <p className="muted small-lines">
              {Object.entries(d.review_notes).sort(([a], [b]) => noteRank(a) - noteRank(b)).map(([k, v]) => <span key={k}><strong>{k}:</strong> {v}<br /></span>)}
              Portfolio funding and resource decisions are reviewed by sponsors. {first}'s workspace tracks personal actions, not portfolio quotas.
            </p>
          </section>
        </>
      )}
    </>
  );
}
