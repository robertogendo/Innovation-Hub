import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Search } from 'lucide-react';
import { useApi } from '../api/client';
import type { ChallengeCardData } from '../api/types';
import { useApp } from '../state/AppContext';
import { PageHeader } from '../components/PageHeader';
import { PortfolioHorizons } from '../components/PortfolioHorizons';
import { ChallengeCard } from '../components/ChallengeCard';
import { ErrorMsg, Loading } from '../components/Bits';

const toggle = (list: string[], v: string) => (list.includes(v) ? list.filter((x) => x !== v) : [...list, v]);
const summary = (list: string[]) => (list.length === 0 ? 'Any' : list.length === 1 ? list[0] : `${list.length} selected`);

export function Explore() {
  const { reference } = useApp();
  const [search, setSearch] = useState('');
  const [debounced, setDebounced] = useState('');
  const [sources, setSources] = useState<string[]>([]);
  const [horizons, setHorizons] = useState<string[]>([]);
  const [types, setTypes] = useState<string[]>([]);

  useEffect(() => { const t = setTimeout(() => setDebounced(search), 250); return () => clearTimeout(t); }, [search]);

  const qs = new URLSearchParams();
  if (debounced.trim()) qs.set('search', debounced.trim());
  sources.forEach((s) => qs.append('source', s));
  horizons.forEach((h) => qs.append('horizon', h));
  types.forEach((t) => qs.append('type', t));
  const result = useApi<{ items: ChallengeCardData[]; total: number }>(`/challenges?${qs.toString()}`);
  const active = sources.length + horizons.length + types.length + (search.trim() ? 1 : 0);
  const clear = () => { setSearch(''); setSources([]); setHorizons([]); setTypes([]); };

  const Chip = ({ label, list, set }: { label: string; list: string[]; set: (v: string[]) => void }) => (
    <button className={`chip ${list.includes(label) ? 'is-active' : ''}`} aria-pressed={list.includes(label)}
            onClick={() => set(toggle(list, label))}>{label}</button>
  );

  return (
    <>
      <PageHeader title="Explore challenges"
                  subtitle="Start with a business problem. Find context, join a team and propose a testable response." />
      <PortfolioHorizons />

      <h2 className="h2">Challenge-led discovery</h2>
      <p className="muted lead">
        Browse by business problem, horizon and innovation type. Each challenge shows one primary strategic horizon
        and the types of innovation most relevant to the opportunity.
      </p>

      <section className="card finder">
        <div className="finder__head">
          <h3>Find a challenge</h3>
          <span className="small muted">Illustrative challenges, sponsors and statuses</span>
        </div>
        <div className="finder__bar">
          <label className="finder__search">
            <Search size={16} />
            <input value={search} onChange={(e) => setSearch(e.target.value)}
                   placeholder="Search by customer journey, business priority, process or capability" aria-label="Search challenges" />
          </label>
          <div className="finder__box"><span>Source</span>{summary(sources)}</div>
          <div className="finder__box"><span>Horizon</span>{summary(horizons)}</div>
          <div className="finder__box"><span>Innovation type</span>{types.length ? summary(types) : '10 Doblin types'}</div>
        </div>
        <div className="finder__groups">
          <div>
            <div className="small muted finder__label">Horizon</div>
            <div className="chips">{reference.horizons.map((h) => <Chip key={h.id} label={h.name} list={horizons} set={setHorizons} />)}</div>
          </div>
          <div>
            <div className="small muted finder__label">Innovation type</div>
            <div className="chips">{reference.innovation_types.map((t) => <Chip key={t.id} label={t.name} list={types} set={setTypes} />)}</div>
          </div>
          <div>
            <div className="small muted finder__label">Source</div>
            <div className="chips">{reference.sources.map((s) => <Chip key={s} label={s} list={sources} set={setSources} />)}</div>
          </div>
        </div>
        <div className="finder__foot small">
          <span className="muted" aria-live="polite">{result.data ? `${result.data.total} of 5 challenges shown` : ''}</span>
          {active > 0 && <button className="linkbtn" onClick={clear}>Clear filters</button>}
        </div>
      </section>

      {result.error && <ErrorMsg text={result.error} />}
      {result.loading && !result.data && <Loading />}
      {result.data && result.data.items.length === 0 && (
        <div className="card empty"><strong>No challenges match these filters.</strong>
          <p className="muted">Try removing a filter, or submit an idea if you do not see the right challenge.</p></div>
      )}
      <div className="grid-2 challenges">
        {result.data?.items.map((c) => <ChallengeCard key={c.id} c={c} />)}
      </div>

      <section className="card support">
        <div className="challenge__top">
          <span className="tagline"><i className="bar" />ILLUSTRATIVE SUPPORT</span>
          <span className="tagline tagline--muted">SOURCE: EMPLOYEE IDEAS</span>
        </div>
        <h3 className="challenge__title">Not seeing the right challenge?</h3>
        <p className="muted">You can still submit an idea. The Innovation team will help route it to the right owner and align it with the most relevant business sponsor.</p>
        <div className="support__foot">
          <span className="small muted">Illustrative support • not actual organisational initiative</span>
          <Link to="/ideas/new" className="btn btn--primary">Submit an idea <ArrowRight size={14} /></Link>
        </div>
      </section>
    </>
  );
}
