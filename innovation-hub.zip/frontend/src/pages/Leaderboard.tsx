import { useState } from 'react';
import { useApi } from '../api/client';
import type { LeaderboardData } from '../api/types';
import { PageHeader } from '../components/PageHeader';
import { Avatar, ErrorMsg, Loading, Tabs } from '../components/Bits';

export function Leaderboard() {
  const [tab, setTab] = useState<'learning' | 'ideas'>('learning');
  const { data, error, loading } = useApi<LeaderboardData>(`/leaderboard?tab=${tab}`);
  return (
    <>
      <PageHeader title="Learning & idea leaders" back={{ to: '/', label: 'Home' }}
                  subtitle="This quarter • Sample rankings. Learning and ideas are ranked separately." />
      <section className="card leaders leaders--full">
        <Tabs tabs={[{ id: 'learning', label: 'Learning' }, { id: 'ideas', label: 'Ideas submitted' }]} value={tab} onChange={setTab} />
        {error && <ErrorMsg text={error} />}
        {loading && !data && <Loading />}
        {data && (
          <>
            <div className="leaders__cols small"><span>COLLEAGUE</span><span>{data.column_label.toUpperCase()}</span></div>
            <ol className="leaders__list">
              {data.entries.map((e) => (
                <li key={e.user_id} className={`leaders__row ${e.is_me ? 'is-me' : ''}`}>
                  <span className="leaders__rank">{e.rank}</span><Avatar initials={e.initials} />
                  <span className="leaders__name">{e.name}{e.is_me ? ' (you)' : ''}</span><strong>{e.value}</strong>
                </li>
              ))}
            </ol>
            <p className="small muted">{data.note}</p>
          </>
        )}
      </section>
    </>
  );
}
