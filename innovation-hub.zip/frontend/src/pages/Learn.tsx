import { FormEvent, useState } from 'react';
import { Link } from 'react-router-dom';
import { Activity, ArrowRight, BarChart3, User } from 'lucide-react';
import { ApiError, api, useApi } from '../api/client';
import type { LearningData, PathCard } from '../api/types';
import { useApp } from '../state/AppContext';
import { PageHeader } from '../components/PageHeader';
import { Placeholder } from '../components/Placeholder';
import { Modal } from '../components/Modal';
import { ErrorMsg, Loading, ProgressBar } from '../components/Bits';

function Recommended({ p }: { p: PathCard }) {
  return (
    <Link to={`/learn/paths/${p.id}`} className="card path">
      <div className="path__img"><Placeholder label="Image placeholder" /><span className="path__badge">{p.badge}</span></div>
      <div className="path__body">
        <h3>{p.title}</h3>
        <p className="muted">{p.description}</p>
        <span className="small red upper path__foot">{p.footer}</span>
        <span className="cta cta--caps">{p.cta} <ArrowRight size={14} /></span>
      </div>
    </Link>
  );
}

export function Learn() {
  const { user, reference } = useApp();
  const { data, error, loading, reload } = useApi<LearningData>('/learning');
  const [mentor, setMentor] = useState(false);
  const [area, setArea] = useState(reference.mentor_areas[0]);
  const [message, setMessage] = useState('');
  const [mentorErr, setMentorErr] = useState<string | null>(null);
  const [sent, setSent] = useState(false);
  const first = user.name.split(' ')[0];

  async function submitMentor(e: FormEvent) {
    e.preventDefault(); setMentorErr(null);
    try { await api.post('/mentor-requests', { area, message }); setSent(true); }
    catch (err) { setMentorErr(err instanceof ApiError ? err.message : 'Could not send the request.'); }
  }
  async function community(join: boolean) { await api.post(`/community/${join ? 'join' : 'leave'}`); reload(); }

  return (
    <>
      <PageHeader title="Learn & connect"
                  subtitle="The Innovation Academy: practical capabilities for the challenges and initiatives you are working on." />
      {error && <ErrorMsg text={error} />}
      {loading && !data && <Loading />}
      {data && (
        <>
          {data.continue && (
            <section className="card card--dark card--accent-dark continue">
              <Activity size={20} className="red" />
              <div className="continue__copy">
                <span className="tagline">CONTINUE LEARNING</span>
                <p>{data.continue.title} • {data.continue.percent}% complete</p>
                {data.continue.recommended_for && <p>Recommended for {data.continue.recommended_for}</p>}
                <ProgressBar percent={data.continue.percent} dark />
              </div>
              <Link to={`/learn/paths/${data.continue.id}`} className="btn btn--primary">Continue learning <ArrowRight size={14} /></Link>
            </section>
          )}

          <h2 className="h2">Recommended for {first}</h2>
          <div className="grid-3">{data.recommended.map((p) => <Recommended key={p.id} p={p} />)}</div>

          <h2 className="h2">Build the capability you need next</h2>
          <div className="grid-2">
            {data.next.map((p) => (
              <Link key={p.id} to={`/learn/paths/${p.id}`} className="card card--accent nextpath">
                <h3>{p.title}</h3><p className="muted">{p.description}</p>
                <span className="cta cta--caps">{p.cta} <ArrowRight size={14} /></span>
              </Link>
            ))}
          </div>

          <section id="types" className="card types-card">
            <h2>Discover the ten types of innovation</h2>
            <p className="muted">One initiative can combine several innovation types and has one primary strategic horizon.</p>
            <div className="grid-2 types-grid">
              {data.types.map((t) => (
                <div key={t.id} className="typetile"><strong>{t.name}</strong><span>{t.short_description}.</span></div>
              ))}
            </div>
          </section>

          <h2 className="h2">People to learn with</h2>
          <div className="grid-2">
            <section className="card people">
              <div className="people__head"><span className="people__icon"><User size={22} /></span>
                <div><h3>Find a mentor</h3><span className="small muted">Customer research, data, operations, tech</span></div></div>
              <p className="muted">Connect with colleagues who have experience in customer research, data, operations or technology.</p>
              <button className="cta cta--caps" onClick={() => { setSent(false); setMentor(true); }}>Request a connection</button>
            </section>
            <section className="card people">
              <div className="people__head"><span className="people__icon"><BarChart3 size={22} /></span>
                <div><h3>Innovation community &amp; collaboration</h3><span className="small muted">Connect across teams</span></div></div>
              <p className="muted">Discuss challenges, share lessons and find collaborators across teams. Bring your claims or partner-onboarding question.</p>
              <div className="people__foot">
                <button className="cta cta--caps" onClick={() => void community(!data.community.joined)}>
                  {data.community.joined ? 'Leave the community' : 'Join the community'}
                </button>
                <span className="small muted">{data.community.joined ? 'You are a member. ' : ''}{data.community.member_count} members (sample)</span>
              </div>
            </section>
          </div>
        </>
      )}

      {mentor && (
        <Modal title="Request a mentor connection" onClose={() => setMentor(false)}>
          {sent ? (
            <>
              <p>Your request has been recorded. The Innovation team will suggest a colleague with experience in {area.toLowerCase()}.</p>
              <button className="btn btn--primary" onClick={() => setMentor(false)}>Close</button>
            </>
          ) : (
            <form onSubmit={submitMentor}>
              <div className="field"><label htmlFor="area">Area of experience</label>
                <select id="area" value={area} onChange={(e) => setArea(e.target.value)}>
                  {reference.mentor_areas.map((a) => <option key={a}>{a}</option>)}
                </select></div>
              <div className="field"><label htmlFor="msg">What would you like help with? (optional)</label>
                <textarea id="msg" rows={3} value={message} onChange={(e) => setMessage(e.target.value)} /></div>
              {mentorErr && <p className="field__error">{mentorErr}</p>}
              <button type="submit" className="btn btn--primary">Send request</button>
            </form>
          )}
        </Modal>
      )}
    </>
  );
}
