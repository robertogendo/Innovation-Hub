import { Link } from 'react-router-dom';
import { ChevronLeft } from 'lucide-react';
import { useApp } from '../state/AppContext';
import { SearchBox } from './SearchBox';

export function PageHeader({ title, subtitle, back }: { title: string; subtitle?: string; back?: { to: string; label: string } }) {
  const { user } = useApp();
  return (
    <header className="topbar">
      <div className="topbar__title">
        {back && <Link to={back.to} className="backlink"><ChevronLeft size={14} /> {back.label}</Link>}
        <h1>{title}</h1>
        {subtitle && <p className="subtitle">{subtitle}</p>}
      </div>
      <div className="topbar__tools">
        <SearchBox />
        <Link to="/help" className="toolbar-link">Help</Link>
        <span className="dot" aria-hidden="true" />
        <span className="toolbar-link">{user.name}</span>
      </div>
    </header>
  );
}
