import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import type { ChallengeCardData } from '../api/types';

export function ChallengeCard({ c }: { c: ChallengeCardData }) {
  return (
    <article className="card challenge">
      <div className="challenge__top">
        <span className="tagline"><i className="bar" />{c.is_illustrative ? 'ILLUSTRATIVE CHALLENGE' : 'CHALLENGE'}</span>
        <span className="tagline tagline--muted">SOURCE: {c.source.toUpperCase()}</span>
      </div>
      <h3 className="challenge__title">{c.title}</h3>
      <p className="challenge__hmw">{c.how_might_we}</p>
      <dl className="kv">
        <div><dt>PRIMARY HORIZON</dt><dd className="red upper">{c.horizon}</dd></div>
        <div><dt>INNOVATION TYPE</dt><dd className="red">{c.types.join(' / ')}</dd></div>
        <div><dt>BUSINESS SPONSOR</dt><dd>{c.sponsor}</dd></div>
        <div><dt>STATUS</dt><dd className="red">{c.status}</dd></div>
      </dl>
      <div className="challenge__foot">
        <span className="small muted">{c.is_illustrative ? 'Illustrative challenge \u2022 not actual organisational initiative' : ''}</span>
        <Link to={`/explore/${c.id}`} className="cta">Explore <ArrowRight size={14} /></Link>
      </div>
    </article>
  );
}
