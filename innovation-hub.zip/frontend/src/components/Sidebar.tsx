import { Link, useLocation } from 'react-router-dom';
import { BarChart3, Book, Home, Lightbulb, Search } from 'lucide-react';
import logo from '../assets/minet-logo-white.png';

const NAV = [
  { to: '/', label: 'Home', icon: Home, active: (p: string) => p === '/' || p.startsWith('/leaderboard') },
  { to: '/explore', label: 'Explore challenges', icon: Search, active: (p: string) => p.startsWith('/explore') },
  { to: '/workspace', label: 'My ideas & experiments', icon: Lightbulb,
    active: (p: string) => p.startsWith('/workspace') || p.startsWith('/ideas') },
  { to: '/learn', label: 'Learn & connect', icon: Book, active: (p: string) => p.startsWith('/learn') },
  { to: '/knowledge', label: 'Knowledge & impact', icon: BarChart3, active: (p: string) => p.startsWith('/knowledge') },
];

export function Sidebar() {
  const { pathname } = useLocation();
  return (
    <aside className="sidebar">
      <Link to="/" aria-label="Minet Innovation Hub home"><img className="sidebar__logo" src={logo} alt="Minet, Secure Tomorrow" /></Link>
      <div className="sidebar__label">Innovation Hub</div>
      <nav className="nav" aria-label="Main">
        {NAV.map(({ to, label, icon: Icon, active }) => (
          <Link key={to} to={to} className={`nav__item ${active(pathname) ? 'is-active' : ''}`}
                aria-current={active(pathname) ? 'page' : undefined}>
            <Icon size={18} strokeWidth={1.6} /> {label}
          </Link>
        ))}
      </nav>
      <Link to="/ideas/new" className="sidebar__cta">
        <strong>Have an idea?</strong>
        <span>Share it. Shape what's next.</span>
      </Link>
    </aside>
  );
}
