import { Image } from 'lucide-react';

export function Placeholder({ label = 'Image placeholder', className = '', dark = false }:
  { label?: string; className?: string; dark?: boolean }) {
  return (
    <div className={`ph ${dark ? 'ph--dark' : ''} ${className}`} role="img" aria-label={label}>
      <Image size={16} strokeWidth={1.5} />
      <span>{label}</span>
    </div>
  );
}
