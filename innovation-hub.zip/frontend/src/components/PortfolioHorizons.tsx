import { useApp } from '../state/AppContext';

export function PortfolioHorizons({ rightNote = 'Portfolio guidance \u2022 not performance' }: { rightNote?: string }) {
  const { reference } = useApp();
  return (
    <section className="card portfolio">
      <div className="portfolio__head">
        <h2>Our strategic Innovation Portfolio</h2>
        <span className="small muted">{rightNote}</span>
      </div>
      <div className="portfolio__grid">
        {reference.horizons.map((h) => (
          <div key={h.id} className="portfolio__item">
            <strong>{h.name}</strong>
            <span>{h.description.replace(/'s business/, "'s business")}</span>
          </div>
        ))}
      </div>
      <p className="small muted portfolio__note">
        These strategic horizons guide our innovation portfolio, not individual employee targets or rigid quotas.
      </p>
    </section>
  );
}
