# Minet Innovation Hub: Understanding and POC Build Plan

**Version:** 2 (decisions from review included)
**Stage:** Proof of concept, local only, not production code
**Inputs:** 6 screen PNGs from the Figma stakeholder wireframe, `Innovation_Desk.css` (Figma export), `minet-logo.png`

---

## 1. Decisions confirmed

| Topic | Decision |
|---|---|
| Backend | FastAPI, included in the POC from the start |
| Database | Local MySQL with a dummy dataset, so ideas and edits persist between restarts |
| Images | Placeholders everywhere except the Minet logo |
| Icons | Use the icons from the Figma file where they can be exported, otherwise Lucide |
| Access control | RBAC is planned for later. The POC is one app where the single mock user (Alex Mwangi) can do everything. The code keeps a seam for roles so RBAC can be added without a rewrite (section 8) |
| Look and copy | Clean and plain. No decorative effects, no filler copy, no em dashes anywhere in the UI or documents |

Still open (assumptions below stand unless you change them): the undesigned screens in section 7, who sees the POC first, and anything in the wireframe you already know will change.

---

## 2. What the application is

The Innovation Hub is an internal portal for Minet's innovation programme. It does four things:

1. **Frames strategy.** Every initiative sits in one of three horizons: Core (protect and optimise today's business), Adjacent (expand into new growth spaces) and Transformational (create future growth engines).
2. **Surfaces business challenges.** Employees browse "How might we" challenges instead of starting from a blank page.
3. **Tracks ideas and experiments** through four gates: Source, Assess, Test, then Scale, Adapt or Stop.
4. **Builds capability and proves value.** An Innovation Academy based on the Doblin ten types of innovation, and an impact view that reports only validated outcomes.

The wireframe shows one persona, Alex Mwangi, an employee. There is no sponsor, triage or admin view yet, which is why RBAC comes later.

### Principles built into the wireframe

| Principle | Where it shows |
|---|---|
| Honest data | Labels such as "Illustrative challenge, not actual organisational initiative", "Sample rankings", "Illustrative counts, not actual performance". These stay in the POC. |
| Evidence before benefit | A benefit is validated only with evidence, a named benefits owner and a measurement period. All three are currently missing, so status is NOT VALIDATED. |
| Guidance, not quotas | "Portfolio guidance, not performance", "not individual employee targets". |
| Low barrier to entry | "No full business case required." Drafts can be saved. |
| Not every idea proceeds | Stage-gate and "Later review considers" blocks. |
| Ranking is separate from quality | Learning and ideas are ranked separately. Idea volume is "not quality or business impact". |

---

## 3. Screens

**Shared shell.** Dark sidebar (230 px) with the logo, five nav items (Home, Explore challenges, My ideas & experiments, Learn & connect, Knowledge & impact), a red active pill, and a pinned "Have an idea?" card. Top bar with page title, subtitle, global search, Help and the user name. The "Our strategic Innovation Portfolio" block appears on Home, Explore and Knowledge, so it is one shared component.

**01 Home.** Greeting and dark hero banner with a "Submit an idea" call to action. Personal dashboard with four tiles (My ideas 2, My active experiments 2, My learning progress 40%, My next actions 3). Learning and idea leaders with two tabs, a top three and Alex's own row (Rank 8). Three "Where you can contribute" cards. One featured opportunity.

**02 Explore challenges.** Search plus filters for Source (Client insights, Employee ideas, Partners, Market signals), Horizon, and Innovation type (ten Doblin types). Five illustrative challenge cards showing source, question, primary horizon, innovation types, sponsor and status. A closing card pointing to Submit an idea.

**03 Submit an idea.** Guided form: title, problem or opportunity, proposed solution, expected value, optional evidence, one primary horizon (including "Not sure"), one or more innovation types, optional collaborators. Info blocks, a "What happens next" rail with four steps, and "Good ideas are specific". Footer has Submit idea and "Drafts can be saved and completed later". The sidebar highlights My ideas & experiments here.

**04 My innovation workspace.** Four records: two ideas at Assess ("Simplify claims status updates", "Customer onboarding checklist") and two experiments at Test ("Digital claims status prototype", "Automated document intake"). The stage-gate model in a dark panel. A selected initiative panel (owner, horizon, types, stage, sponsor, evidence, next decision on 18 Nov) and a "Before the next decision" checklist.

**05 Learn & connect.** Continue learning banner at 40%, three recommended cards, two "build the capability you need next" cards tied to Alex's own records, the ten innovation types grid, and two "people to learn with" cards (mentor, community).

**06 Knowledge & impact.** Illustrative activity strip (86 ideas submitted, 12 experiments underway, 4 pilots launched, validated outcomes "Not yet validated"). A statement block. Impact reporting across the three horizons, every metric "To be measured, evidence pending". The "When can a benefit be called validated?" rule box. Knowledge library tiles and a governance block.

---

## 4. Data model (MySQL)

Database name: `innovation_hub`. Created by `schema.sql` and filled by an idempotent `seed.py`, so the dummy data can be reset at any time.

| Table | Purpose and main columns |
|---|---|
| `users` | id, name, initials, email, role (single value for now, used later for RBAC) |
| `horizons` | id, name, description (3 rows) |
| `innovation_types` | id, name, short_description (10 Doblin rows) |
| `stages` | id, name, sort_order, description (Source, Assess, Test, Scale/Adapt/Stop) |
| `challenges` | id, title, how_might_we, source, horizon_id, sponsor, status, is_illustrative, is_featured |
| `challenge_types` | challenge_id, type_id |
| `ideas` | id, reference_id, title, problem, solution, expected_value, evidence, horizon_id (nullable for "Not sure"), collaborators, status (Draft, Submitted, In review, Needs clarification), stage_id, owner_id, next_action, challenge_id (nullable), created_at, updated_at |
| `idea_types` | idea_id, type_id |
| `experiments` | id, title, owner_id, horizon_id, stage_id, status (Testing, Learning captured), next_decision_text, next_decision_date, sponsor, evidence_learning, resource_decision, idea_id (nullable) |
| `experiment_types` | experiment_id, type_id |
| `learning_paths` | id, title, description, tags, linked_experiment_id (nullable) |
| `user_learning_progress` | user_id, path_id, progress_percent, completed_at |
| `colleagues` | id, name, initials (sample people for the leaderboard) |
| `leaderboard_stats` | colleague_id, period, completed_paths, ideas_submitted |
| `impact_metrics` | id, horizon_id, name, status, evidence, benefits_owner, measurement_period, validated (derived, see below) |
| `portfolio_stats` | ideas_submitted, experiments_underway, pilots_launched (illustrative figures) |
| `library_items` | id, category, title, description |

Rules enforced in the backend, not only in the copy:
- `validated` on an impact metric is true only when evidence, benefits owner and measurement period are all present. The seed data leaves all three empty.
- Reference IDs for new ideas follow one format, for example `IDEA-2026-0001`.
- Home counts and workspace lists are computed from the tables, so a newly submitted idea shows up everywhere it should. The Alex-specific figures (40% progress, 18 Nov date, 2 ideas, 2 experiments, Rank 8) must agree on every screen that shows them.

## 5. API outline (FastAPI)

| Method and path | Used by |
|---|---|
| `GET /api/reference` (horizons, types, stages) | All screens |
| `GET /api/home` | Home dashboard tiles, featured challenge |
| `GET /api/leaderboard?tab=learning\|ideas` | Home |
| `GET /api/challenges?search=&source=&horizon=&type=` | Explore |
| `GET /api/challenges/{id}` | Challenge detail |
| `GET /api/ideas`, `GET /api/ideas/{id}` | Workspace |
| `POST /api/ideas`, `PUT /api/ideas/{id}` (draft or submit) | Submit an idea |
| `GET /api/experiments`, `GET /api/experiments/{id}` | Workspace |
| `GET /api/learning` | Learn & connect |
| `GET /api/impact` | Knowledge & impact |
| `GET /api/search?q=` | Global search |

Pydantic models validate every request. Pages never talk to MySQL directly.

---

## 6. Design system from the CSS

`Innovation_Desk.css` is a raw Figma export (about 257 KB, every element absolutely positioned at 1440 px, roughly 540 text styles). It is not reusable as written. It is used for tokens and measurements, and layouts are rebuilt with flex and grid.

**Colour**

| Token | Hex | Use |
|---|---|---|
| `--red` | `#E21A22` | Primary: active nav, buttons, labels, progress, left borders |
| `--ink` | `#222222` | Sidebar, headings, dark panels |
| `--text-muted` | `#666666` | Body and secondary text |
| `--border` | `#DDDDDD` | Card borders |
| `--bg` | `#F2F2F2` | Page background |
| `--surface` | `#FFFFFF` | Cards |
| `--surface-alt` | `#F7F7F7`, `#EAEAEA` | Row stripes, avatar circles |
| `--nav-text`, `--nav-icon` | `#DDDDDD`, `#BBBBBB` | Sidebar text and icons |
| `--red-tint` | `#FBE0E1`, `#E8AAAC` | "What happens next" panel |

Other greys in use: `#999999`, `#AAAAAA`, `#444444`, `#555555`, `#3B3B3B`.

**Type.** Inter only, weights 400, 600 and 700. Sizes used: 9, 10, 11, 12, 13 (base UI), 14, 16, 18 to 22, 26.

**Shape.** Cards 12 px radius, white, 1 px `#DDDDDD` border, no shadows. Inner tiles and the nav pill 8 px. Chips and tabs 6 to 7 px. Featured cards carry a 4 px red left border.

**Layout.** 1440 px design width, 230 px sidebar, content from 270 px, about 1135 px wide, 20 to 24 px card padding.

**Keeping it clean.** No gradients, no glow, no emoji, no decorative illustration. Flat cards, one accent colour, real spacing, plain sentence-case copy taken from the wireframe. Hover and focus states are subtle (border or background change only).

**Logo.** `minet-logo.png` (900 by 528, transparent) has the Minet mark, "Secure Tomorrow" and the Centre for Innovation and Analytics lockup in red and black. The sidebar is dark `#222222`, where the black text would disappear, and the wireframe shows a white logo there. Proposal: crop to the Minet mark and tagline, and make a white reversed version for the sidebar. Keep the original colour version for light areas, and keep the CIA lockup available for a footer or sign-in page. If brand rules do not allow a reversed logo, the fallback is a light tile at the top of the sidebar.

**Icons.** Figma icons if exportable as SVG, otherwise Lucide (the nav icons in the CSS are home, search, lightbulb, book and bar chart, all in Lucide).

**Images.** Neutral grey placeholder blocks, sized to the wireframe slots (hero banner, three Learn cards), each easy to swap for a real file later.

---

## 7. POC scope

### In scope
- All six screens at 1440 px desktop width, matching the PNGs.
- Working navigation, including every "Submit an idea", "Open record" and "Explore" link.
- Explore: search and Source, Horizon and Innovation type filters, with an empty state.
- Submit an idea: validation, save draft, submit, reference ID, confirmation. The saved idea appears in the workspace and changes the Home counts. Data is stored in MySQL.
- Workspace: Open record changes the selected initiative panel.
- Home leaderboard tabs.
- Learn & connect and Home share the same progress data.
- Knowledge & impact: the validation rule is evaluated from data.
- Global search across challenges, ideas and experiments.
- All "illustrative" labels kept.
- Seed and reset scripts for the dummy database.

### Out of scope
- Login, SSO, roles and permissions (RBAC later).
- Notifications, email, comments, file uploads.
- Real Minet data and integrations.
- Mobile and tablet layouts (desktop first, nothing should break at 1280 px and above).
- Accessibility audit, load testing, deployment, CI/CD.

### Gaps in the wireframe and the assumption for each
| Gap | Assumption |
|---|---|
| "Ideas submitted" leaderboard tab not shown | Same layout as the Learning tab, ranked by ideas submitted |
| Challenge detail ("Explore this challenge") not designed | A simple detail page with the card content and a "Submit an idea for this challenge" button |
| Idea detail ("Open record" for ideas) not designed | Reuse the selected initiative layout |
| View full leaderboard, Academy, mentor, community, library links | Styled correctly, show a short "Not part of the POC" message |
| Help and user menu | Static |
| Sidebar wordmark differs between screens ("Innovation Hub" and "INNOVATION HUB", positions) | Standardise on one |

---

## 8. Technical approach

Same pattern as Project Sentinel and Brokerage Analytics: local first, Windows friendly, FastAPI and MySQL behind a React front end.

| Layer | Choice |
|---|---|
| Frontend | React, TypeScript, Vite |
| Routing | React Router, one route per screen plus `/ideas/:id` and `/challenges/:id` |
| Styling | CSS variables for tokens and CSS Modules. No UI library. |
| Fonts and icons | `@fontsource/inter` (self-hosted, works offline), Figma SVGs or `lucide-react` |
| State | React Context for the current user and a small data layer calling the API |
| Backend | FastAPI, SQLAlchemy, PyMySQL, Pydantic |
| Database | Local MySQL, schema in `schema.sql`, seed in `seed.py`, connection in `.env` |
| Run | `uvicorn` for the API, `npm run dev` for the front end, README with Windows steps |

### RBAC seam (no roles yet)
- `users.role` exists but every check passes for the mock user.
- A single FastAPI dependency (`get_current_user`) returns Alex today. Later it reads a real login.
- Write endpoints call a `require_permission("idea:create")` helper that currently always allows. Roles map to permissions in one file later.
- The front end uses a `useCan("idea:create")` hook that currently returns true, so buttons can be hidden per role without touching pages.

### Folder structure
```
innovation-hub/
  frontend/
    src/
      styles/        tokens.css, global.css
      components/    Sidebar, TopBar, Card, Chip, Tabs, ProgressBar,
                     PortfolioHorizons, StageGate, ChallengeCard
      pages/         Home, Explore, SubmitIdea, Workspace, Learn, Knowledge
      api/           typed client functions
      state/         user context
      assets/        logo files, image placeholders
  backend/
    app/             main.py, db.py, models.py, schemas.py, routers/, security.py
    schema.sql
    seed.py
    .env.example
  reference/         the 6 PNGs and Innovation_Desk.css
  README.md
```

---

## 9. Build phases

| Phase | Work | Done when |
|---|---|---|
| 0. Setup | Project scaffolds, Inter, tokens, logo variants, MySQL database and `schema.sql`, `seed.py` | Both servers start, seed fills the tables, API returns reference data |
| 1. Shell | Sidebar, top bar, layout, shared components, routing | Shell and active states match the PNGs |
| 2. Read-only screens | Home, Explore, Learn, Knowledge, Workspace wired to the API | Each page matches its PNG at 1440 px with data from MySQL |
| 3. Interactions | Explore filters, leaderboard tabs, Open record, Submit with validation, draft and submit, counts update | Full click-through works and data survives a restart |
| 4. Review | Placeholder pass, label audit, empty and error states, screenshot comparison against the PNGs, short demo script | Walkthrough is smooth |

Checking method: after each phase, take screenshots at 1440 px and compare with the PNGs, and list differences instead of quietly adjusting. Cross-screen consistency (40%, 18 Nov, 2 ideas, 2 experiments, Rank 8) is checked every time.

---

## 10. Risks

- Copying the Figma CSS directly would give a brittle, non-responsive result, so it is used for values only.
- If the POC is shown to executives, the illustrative labels are what stop it being read as real performance. They stay.
- The Knowledge screen must never show a benefit as realised without all three validation conditions, which is why the rule lives in the backend.
- A reversed (white) logo may need brand approval.
- Scope drift toward production. Auth, roles and integrations are deliberately absent, and the sponsor and triage experience is not yet designed in the wireframes.

## 11. Open items

1. Is the reversed white logo acceptable for the dark sidebar, or should I use a light tile?
2. Are the gap assumptions in section 7 fine?
3. Who sees the POC first? This decides how much polish phase 4 needs.
4. Is there anything in the wireframe you already know will change?
5. Which MySQL version and local credentials should the `.env.example` assume? (Your other local stack runs MySQL 9.7 on Windows Server.)
