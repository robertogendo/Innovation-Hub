"""Create the MySQL database, tables and dummy data.

    python init_db.py            create database and tables, seed only if empty
    python init_db.py --reset    drop all tables, recreate and reseed
"""
import sys

from sqlalchemy import create_engine, text

from app import models  # noqa: F401  (registers tables)
from app.db import Base, SessionLocal, database_name, engine, server_url
from seed import seed


def main(reset: bool) -> None:
    name = database_name()
    server = create_engine(server_url(), isolation_level="AUTOCOMMIT")
    with server.connect() as conn:
        conn.execute(text(f"CREATE DATABASE IF NOT EXISTS `{name}` "
                          "CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"))
    if reset:
        Base.metadata.drop_all(engine)
        print("Dropped existing tables.")
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        if db.query(models.User).count() == 0:
            seed(db)
            print("Seeded dummy data.")
        else:
            print("Data already present. Use --reset to start again.")
    print(f"Database '{name}' is ready.")


if __name__ == "__main__":
    main("--reset" in sys.argv)
