from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .routers import challenges, home, ideas, knowledge, leaderboard, learning, reference, search

app = FastAPI(title="Minet Innovation Hub API (POC)", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_methods=["*"], allow_headers=["*"],
)
for module in (reference, home, challenges, ideas, learning, leaderboard, knowledge, search):
    app.include_router(module.router)
