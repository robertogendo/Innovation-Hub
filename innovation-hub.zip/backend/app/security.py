"""Current user and permission seam.

The POC has one mock user and every permission is allowed. When RBAC arrives:
  1. replace `get_current_user` with a real login lookup,
  2. fill in ROLE_PERMISSIONS,
  3. keep `require_permission(...)` on the routes, which already call it.
"""
import os

from fastapi import Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from .db import get_db
from .models import User

# POC: every role may do everything.
ROLE_PERMISSIONS: dict[str, set[str]] = {"Employee": {"*"}}


def permissions_for(user: User) -> list[str]:
    return sorted(ROLE_PERMISSIONS.get(user.role, set()))


def has_permission(user: User, permission: str) -> bool:
    granted = ROLE_PERMISSIONS.get(user.role, set())
    return "*" in granted or permission in granted


def get_current_user(db: Session = Depends(get_db)) -> User:
    email = os.getenv("POC_USER_EMAIL", "alex.mwangi@example.com")
    user = db.scalar(select(User).where(User.email == email))
    if not user:
        raise HTTPException(500, "Mock user not found. Run `python init_db.py` first.")
    return user


def require_permission(permission: str):
    def dependency(user: User = Depends(get_current_user)) -> User:
        if not has_permission(user, permission):
            raise HTTPException(403, f"Missing permission: {permission}")
        return user
    return dependency
